package com.cts;

public interface IServices {

	public void service();
}
