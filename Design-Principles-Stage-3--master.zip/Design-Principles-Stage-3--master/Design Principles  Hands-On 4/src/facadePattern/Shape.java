package facadePattern;

public interface Shape {
	   void draw();
}