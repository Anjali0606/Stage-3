package com.abstractFactory;

enum CarType {
	MICRO, MINI, LUXURY;
}
