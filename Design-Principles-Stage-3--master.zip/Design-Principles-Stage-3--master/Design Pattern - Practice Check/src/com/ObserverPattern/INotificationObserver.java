package com.ObserverPattern;

public interface INotificationObserver {

	String observerName = null;

	public void OnServerDown();
}
