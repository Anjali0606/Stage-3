package com.cts;

public interface IOrderRepair {
	
	public void processOrder(String modelName);
	
	public void processPhoneRepair(String modelName);

	public void processAccessorRepair(String accessoryType);

}
