package com.cts;

public interface IOrder extends IServices {
	
	public void processOrder(String modelName);
	
}
