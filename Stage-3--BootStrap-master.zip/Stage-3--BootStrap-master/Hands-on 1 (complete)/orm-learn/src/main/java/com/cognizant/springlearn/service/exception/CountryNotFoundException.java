package com.cognizant.springlearn.service.exception;

public class CountryNotFoundException extends Exception {

	public CountryNotFoundException(String str) {
		super(str);
	}
}
